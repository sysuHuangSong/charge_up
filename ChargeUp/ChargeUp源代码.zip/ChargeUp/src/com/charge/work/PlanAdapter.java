package com.charge.work;

import java.util.ArrayList;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

/**
 * 
 * @author Carmack
 * 
 */
public class PlanAdapter extends BaseAdapter {
	private Context context;
	private LayoutInflater layoutInflater;
	private ArrayList<PlanUnit> list;

	public PlanAdapter(Context context, ArrayList<PlanUnit> list) {
		super();
		this.context = context;
		this.layoutInflater = LayoutInflater.from(this.context);
		this.list = list;
		Log.e("", list.size() + "!");
	}

	public int getCount() {
		return this.list != null ? this.list.size() : 0;
	}

	public Object getItem(int position) {
		return this.list != null ? this.list.get(position) : null;
	}

	public long getItemId(int position) {
		return position;
	}

	public View getView(int position, View convertView, ViewGroup parent) {
		ListItem listitem = null;
		if (position >= list.size())
			return null;
		final int pos = position;
		if (convertView == null) {
			listitem = new ListItem();
			convertView = layoutInflater.inflate(R.layout.plan_item, null);
			listitem.tv_Month = (TextView) convertView
					.findViewById(R.id.textView_month);
			listitem.tv_Salary = (TextView) convertView
					.findViewById(R.id.textView_salary);
			listitem.tv_Reward = (TextView) convertView
					.findViewById(R.id.textView_reward);
			listitem.tv_Gain = (TextView) convertView
					.findViewById(R.id.textView_gain);

			listitem.tv_Food = (TextView) convertView
					.findViewById(R.id.textView_food);
			listitem.tv_Clothes = (TextView) convertView
					.findViewById(R.id.textView_clothes);
			listitem.tv_Life = (TextView) convertView
					.findViewById(R.id.textView_life);
			listitem.tv_Play = (TextView) convertView
					.findViewById(R.id.textView_play);

			convertView.setTag(listitem);
		} else {
			listitem = (ListItem) convertView.getTag();
		}

		// 设置数据
		if (list != null) {
			listitem.tv_Month.setText("" + list.get(position).getPlanMonth());
			listitem.tv_Salary.setText("" + list.get(position).getCountOfSalary());
			listitem.tv_Reward.setText("" + list.get(position).getCountOfReward());
			listitem.tv_Gain.setText("" + list.get(position).getCountOfGain());
			listitem.tv_Food.setText("" + list.get(position).getCountOfFood());
			listitem.tv_Clothes.setText("" + list.get(position).getCountOfClothes());
			listitem.tv_Life.setText("" + list.get(position).getCountOfLife());
			listitem.tv_Play.setText("" + list.get(position).getCountOfPlay());
		}
		return convertView;
	}

	/**
	 * 设置新数据并且更新UI
	 * 
	 * @param list
	 */
	public void setData(ArrayList<PlanUnit> data) {
		list = null;
		list = data;
		notifyDataSetChanged();
	}

	public void free() {
		list = null;
	}

	public class ListItem {
		public TextView tv_Month;
		public TextView tv_Salary;
		public TextView tv_Reward;
		public TextView tv_Gain;
		public TextView tv_Food;
		public TextView tv_Clothes;
		public TextView tv_Life;
		public TextView tv_Play;
	}

}