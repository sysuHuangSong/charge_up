package com.charge.work;

/**
 * 数据单元
 * 
 * @author carmack
 * 
 */
public class PlanUnit {
//	private int planType;// 计划类型：收入 支出
//	public static final int PLAN_TYPE_INCOME = 101;// 收入
//	public static final int PLAN_TYPE_EXPENSES = 102;// 支出

	private int planMonth;// 计划月份

	private int countOfSalary;// 工资金额
	private int countOfReward;// 奖金金额
	private int countOfGain;// 外快金额

	private int countOfFood;// 外出就餐金额
	private int countOfClothes;// 服装金额
	private int countOfLife;// 日常开支金额
	private int countOfPlay;// 娱乐交际金额

	
	public PlanUnit(int planMonth, int countOfSalary,
			int countOfReward, int countOfGain, int countOfFood,
			int countOfClothes, int countOfLife, int countOfPlay) {
		super();
		this.planMonth = planMonth;
		this.countOfSalary = countOfSalary;
		this.countOfReward = countOfReward;
		this.countOfGain = countOfGain;
		this.countOfFood = countOfFood;
		this.countOfClothes = countOfClothes;
		this.countOfLife = countOfLife;
		this.countOfPlay = countOfPlay;
	}

//	public int getPlanType() {
//		return planType;
//	}
//
//	public void setPlanType(int planType) {
//		this.planType = planType;
//	}

	public int getPlanMonth() {
		return planMonth;
	}

	public void setPlanMonth(int planMonth) {
		this.planMonth = planMonth;
	}

	public int getCountOfSalary() {
		return countOfSalary;
	}

	public void setCountOfSalary(int countOfSalary) {
		this.countOfSalary = countOfSalary;
	}

	public int getCountOfReward() {
		return countOfReward;
	}

	public void setCountOfReward(int countOfReward) {
		this.countOfReward = countOfReward;
	}

	public int getCountOfGain() {
		return countOfGain;
	}

	public void setCountOfGain(int countOfGain) {
		this.countOfGain = countOfGain;
	}

	public int getCountOfFood() {
		return countOfFood;
	}

	public void setCountOfFood(int countOfFood) {
		this.countOfFood = countOfFood;
	}

	public int getCountOfClothes() {
		return countOfClothes;
	}

	public void setCountOfClothes(int countOfClothes) {
		this.countOfClothes = countOfClothes;
	}

	public int getCountOfLife() {
		return countOfLife;
	}

	public void setCountOfLife(int countOfLife) {
		this.countOfLife = countOfLife;
	}

	public int getCountOfPlay() {
		return countOfPlay;
	}

	public void setCountOfPlay(int countOfPlay) {
		this.countOfPlay = countOfPlay;
	}

}
