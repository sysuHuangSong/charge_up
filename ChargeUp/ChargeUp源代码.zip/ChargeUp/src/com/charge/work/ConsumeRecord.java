package com.charge.work;

/**
 * 消费记录(收支)
 * 
 * @author carmack
 * 
 */
public class ConsumeRecord {
	private int type;
	public static final int TYPE_INCOME = 100;
	public static final int TYPE_EXPENSES = 101;
	private int itemType;

	public static final int ITEM_TYPE_SALARY = 200;
	public static final int ITEM_TYPE_REWARD = 201;
	public static final int ITEM_TYPE_GAIN = 202;

	public static final int ITEM_TYPE_FOOD = 300;
	public static final int ITEM_TYPE_CLOTHES = 301;
	public static final int ITEM_TYPE_LIFE = 302;
	public static final int ITEM_TYPE_PLAY = 303;

	private int month;
	private String time;
	private int money;

	public ConsumeRecord(int type, int itemType, int month, String time,
			int money) {
		super();
		this.type = type;
		this.itemType = itemType;
		this.month = month;
		this.time = time;
		this.money = money;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public int getItemType() {
		return itemType;
	}

	public void setItemType(int itemType) {
		this.itemType = itemType;
	}

	public int getMonth() {
		return month;
	}

	public void setMonth(int month) {
		this.month = month;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public int getMoney() {
		return money;
	}

	public void setMoney(int money) {
		this.money = money;
	}

}
