package com.charge.work;

import java.util.ArrayList;

import com.charge.work.R;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TimePicker;
import android.widget.Toast;
/**
 * 新增一条数据的页面
 * @author carmack
 *
 */
public class AddActivity extends Activity {

	Button btnManage, btnAdd, btnChart,btnAddOne;
	Spinner spinnerIncomeExpenses,spinnerItem;
	
	DatePicker datePicker;
	EditText editTextMoney;
	private static final String[] IncomeExpenses={"收入","支出"};  
	private static final String[] TypesIncome={"工资","奖金","外快"};  
	private static final String[] TypesExpenses={"外出就餐","服装鞋帽","日常开支","娱乐交际"};  
	
	private ArrayAdapter<String> adapterIncomeExpenses;  
	private ArrayAdapter<String> adapterTypesIncome;  
	private ArrayAdapter<String> adapterTypesExpenses;  

	int indexIncomeOrExpenses;
	
	
	int type;
	int itemType;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_add);
		initView();
	}

	public void initView() {
		datePicker = (DatePicker) findViewById(R.id.datePicker1);
		
		spinnerIncomeExpenses = (Spinner) findViewById(R.id.spinner_income_expenses);
		spinnerItem = (Spinner) findViewById(R.id.spinner_item);

		 //将可选内容与ArrayAdapter连接起来  
		adapterIncomeExpenses = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,IncomeExpenses);  
          
        //设置下拉列表的风格  
		adapterIncomeExpenses.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);  
          
        //将adapter 添加到spinner中  
        spinnerIncomeExpenses.setAdapter(adapterIncomeExpenses);  
        indexIncomeOrExpenses = 0;
        
      //将可选内容与ArrayAdapter连接起来  
        adapterTypesIncome = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,TypesIncome);  
        adapterTypesExpenses = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,TypesExpenses);  
      //设置下拉列表的风格  
        adapterTypesIncome.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);  
        adapterTypesExpenses.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);  
      //添加事件Spinner事件监听    
        spinnerItem.setOnItemSelectedListener(new OnItemSelectedListener() {
        	
        	@Override
        	public void onItemSelected(AdapterView<?> parent, View view,
        			int position, long id) {
        		if (indexIncomeOrExpenses == 0) {//收入
        			switch (position) {
        			case 0:
        				itemType = ConsumeRecord.ITEM_TYPE_SALARY;
        				break;
        			case 1:
        				itemType = ConsumeRecord.ITEM_TYPE_REWARD;
        				break;
        			case 2:
        				itemType = ConsumeRecord.ITEM_TYPE_GAIN;
        				break;
        			default:
        				break;
        			}
				}else if(indexIncomeOrExpenses == 1){//支出
					switch (position) {
					case 0:
						itemType = ConsumeRecord.ITEM_TYPE_FOOD;
						break;
					case 1:
						itemType = ConsumeRecord.ITEM_TYPE_CLOTHES;
						break;
					case 2:
						itemType = ConsumeRecord.ITEM_TYPE_LIFE;
						break;
					case 3:
						itemType = ConsumeRecord.ITEM_TYPE_PLAY;
						break;
					default:
						break;
					}
				}
        	}
        	
        	@Override
        	public void onNothingSelected(AdapterView<?> parent) {
        		
        	}
        });  
        
        //添加事件Spinner事件监听    
        spinnerIncomeExpenses.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> parent, View view,
					int position, long id) {
				if (position == 0) {
			        //将adapter 添加到spinner中  
			        spinnerItem.setAdapter(adapterTypesIncome);  
			        indexIncomeOrExpenses = 0;
			        type = ConsumeRecord.TYPE_INCOME;
				}else{
			        //将adapter 添加到spinner中  
			        spinnerItem.setAdapter(adapterTypesExpenses);  
			        indexIncomeOrExpenses = 1;
			        type = ConsumeRecord.TYPE_EXPENSES;
				}
				spinnerItem.setVisibility(View.VISIBLE);  
			}

			@Override
			public void onNothingSelected(AdapterView<?> parent) {
				
			}
		});  
        spinnerIncomeExpenses.setVisibility(View.VISIBLE);  
        
		
		
		editTextMoney = (EditText) findViewById(R.id.edit_money);
		
		btnAddOne = (Button) findViewById(R.id.btn_add_one);
		btnAddOne.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				int month = datePicker.getMonth() + 1;
				String time = month +"月"+datePicker.getDayOfMonth()+"日";
				Log.e("tag", "month:"+month+":"+datePicker.getDayOfMonth());
				int money = 0;
				try {
					money = Integer.valueOf(editTextMoney.getText().toString());
				} catch (NumberFormatException e) {
					e.printStackTrace();
					Toast.makeText(getApplicationContext(), "请输入正确金额！", Toast.LENGTH_SHORT).show();
					return;
				}
				ConsumeRecord record = new ConsumeRecord(type, itemType, month,time, money);
				PlanActivity.consumeRecords.add(record);
				
				Toast.makeText(getApplicationContext(), "成功增加一条收支记录！", Toast.LENGTH_SHORT).show();
					
			}
		});
		
		btnManage = (Button) findViewById(R.id.btn_manage);
		btnAdd = (Button) findViewById(R.id.btn_add);
		btnChart = (Button) findViewById(R.id.btn_chart);

		btnAdd.setPressed(true);

		btnManage.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent1 = new Intent(getApplicationContext(),
						PlanActivity.class);
				startActivity(intent1);
				finish();
			}
		});
		btnAdd.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				
			}
		});
		btnChart.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent2 = new SalesStackedBarChart().execute(getApplicationContext());
				startActivity(intent2);
				finish();
			}
		});

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}
