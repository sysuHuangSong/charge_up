/**
 * Copyright (C) 2009 - 2013 SC 4ViewSoft SRL
 *  
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *  
 *      http://www.apache.org/licenses/LICENSE-2.0
 *  
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.charge.work;

import java.util.ArrayList;
import java.util.List;

import org.achartengine.ChartFactory;
import org.achartengine.chart.BarChart.Type;
import org.achartengine.renderer.XYMultipleSeriesRenderer;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Paint.Align;

/**
 * Sales demo bar chart.
 */
public class SalesStackedBarChart extends AbstractDemoChart {
	/**
	 * Returns the chart name.
	 * 
	 * @return the chart name
	 */
	public String getName() {
		return "Sales stacked bar chart";
	}

	/**
	 * Returns the chart description.
	 * 
	 * @return the chart description
	 */
	public String getDesc() {
		return "The monthly sales for the last 2 years (stacked bar chart)";
	}

	/**
	 * Executes the chart demo.
	 * 
	 * @param context
	 *            the context
	 * @return the built intent
	 */
	public Intent execute(Context context) {
		String[] titles = new String[] { "外出就餐", "服装鞋帽", "日常开支", "娱乐交际" };
		List<double[]> values = new ArrayList<double[]>();
		values.add(new double[] { 300, 400, 330, 430, 150, 280,
				220, 500, 100, 300, 120, 170 });
		values.add(new double[] { 530, 700, 240, 240, 100, 200, 130,
				100, 95, 300, 600, 800 });
		values.add(new double[] { 1430, 1230, 1420, 1544, 1520, 1300,
				1130, 1100, 1500, 1250, 1260, 1400 });
		values.add(new double[] { 230, 300, 240, 540, 790, 210, 203,
				110, 95, 105, 116, 135 });
		int[] colors = new int[] { Color.BLUE, Color.CYAN ,Color.RED,Color.GREEN};
		XYMultipleSeriesRenderer renderer = buildBarRenderer(colors);
		// 设置样式表，使用父类定义中的方法
		setChartSettings(renderer, "12个月各项消费柱状图",
				"月份", "金额", 0.5, 12.5, 0, 3000, Color.GRAY,
				Color.LTGRAY);
		renderer.setXLabels(12);
		// renderer.setXLabels(1);
		renderer.setYLabels(10);

		// 下面的for循环是我自己添加的，目的只是想试验一下setXLable和addTexLabel的效果，比如上面的语句里我分//别尝试了setXLables(12)和setXLables(1)。
//		for (int i = 0; i < 12; i++) {
//			renderer.addTextLabel(i + 1, "xkk");
//			// Adds a new text label for the specified X axis value. use
//			// addXTextLabel instead
//			// 为刻度值添加label，如果不添加label则会以数字显示
//		}

		renderer.setDisplayChartValues(true);// Sets if the chart point values
												// should be displayed as text.
		renderer.setXLabelsAlign(Align.CENTER);// Sets the X axis labels
												// alignment. 是lable在刻度值的位置
		renderer.setYLabelsAlign(Align.LEFT);
		// renderer.setPanEnabled(false);
		// renderer.setZoomEnabled(false);
		renderer.setZoomRate(1.1f);// Sets the zoom rate
		renderer.setBarSpacing(0.5);
		// Sets the spacing between bars, in bar charts.
		// Only available for bar charts. This is a coefficient of the bar
		// width.
		// For instance, if you want the spacing to be a half of the bar width,
		// set this value to 0.5.
		return ChartFactory.getBarChartIntent(context,
				buildBarDataset(titles, values), renderer, Type.DEFAULT);
		// 这里使用了枚举Type.STACKED，上一节使用的是Type.DEFAULT。所以，如果想要叠在一起的就使用
		// //STACKED。不过要注意的是，STACKED这个样式之支持两组数据集，如果>=三个的话则会出现柱状的混乱。
		// 这个本人已经验证过了。。。。。很明显嘛，查一下STACKED的意思，是“二叠分”
	}

}
