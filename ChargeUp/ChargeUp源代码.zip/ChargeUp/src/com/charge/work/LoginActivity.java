package com.charge.work;

import com.charge.work.R;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
/**
 * 登录页面
 * @author carmack
 *
 */
public class LoginActivity extends Activity {
	
	TextView titleView;
	EditText editTextUserName;
	EditText editTextPsw;
	Button loginButton;
	final String USER_NAME = "admin";//测试账号
	final String USER_PSW = "123456";
	String userName,psw;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_login);
		initView();
	}
	
	public void initView()
	{
		titleView = (TextView)findViewById(R.id.title);
//		titleView.setText("");
		
		editTextUserName = (EditText)findViewById(R.id.editText_username);
		editTextPsw = (EditText)findViewById(R.id.editText_psw);
		//初始时设置账号用于免输入
		editTextUserName.setText("admin");
		editTextPsw.setText("123456");

		loginButton = (Button)findViewById(R.id.btn_login);
		
		loginButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO 自动生成的方法存根
				userName = editTextUserName.getText().toString();
				psw = editTextPsw.getText().toString();
				
				if(userName != null && userName.equals("admin") && psw != null && psw.equals("123456")){
					Toast.makeText(getApplicationContext(), "登录成功！", Toast.LENGTH_SHORT).show();
					Intent intent = new Intent(getApplicationContext(), PlanActivity.class);
					startActivity(intent);
					finish();
				}else{
					//登录错误提示
					Toast.makeText(getApplicationContext(), "用户名和密码错误，请重试！", Toast.LENGTH_SHORT).show();
				}
			}
		});
	}
}
