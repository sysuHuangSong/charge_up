package com.charge.work;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.Toast;

/**
 * 记账计划
 * 
 * @author carmack
 * 
 */
public class PlanActivity extends Activity {

	EditText editText_salary, editText_reward, editText_gain, editText_food,
			editText_clothes, editText_life, editText_play, editText_month;
	Button btnManage, btnAdd, btnChart, btnReview, btnModify, btnSubmit,btnBack;

	ListView listViewPlan;

	ScrollView scrollViewPlan;

	PlanAdapter adapter;
	RecordAdapter recordAdapter;
	
	private static final int INDEX_PLAN = 1001;
	private static final int INDEX_RECORD = 1002;
	int indexAdapter = INDEX_PLAN;
	
	public static ArrayList<PlanUnit> planLists = new ArrayList<PlanUnit>(12);
	public static ArrayList<ConsumeRecord> consumeRecords = new ArrayList<ConsumeRecord>(
			0);
	ArrayList<ConsumeRecord> currentRecords = new ArrayList<ConsumeRecord>();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_plan);
		initView();
	}

	public void initView() {
		editText_month = (EditText) findViewById(R.id.edit_month);

		editText_salary = (EditText) findViewById(R.id.edit_salary);
		editText_reward = (EditText) findViewById(R.id.edit_reward);
		editText_gain = (EditText) findViewById(R.id.edit_gain);

		editText_food = (EditText) findViewById(R.id.edit_food);
		editText_clothes = (EditText) findViewById(R.id.edit_clothes);
		editText_life = (EditText) findViewById(R.id.edit_life);
		editText_play = (EditText) findViewById(R.id.edit_play);

		scrollViewPlan = (ScrollView) findViewById(R.id.scrollViewPlan);
		listViewPlan = (ListView) findViewById(R.id.listViewPlan);

		btnBack = (Button) findViewById(R.id.btn_back);
		btnBack.setVisibility(View.GONE);
		btnBack.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				indexAdapter = INDEX_PLAN;
				btnBack.setVisibility(View.GONE);
				showPlanLists(true);
			}
		});
		
		btnReview = (Button) findViewById(R.id.btn_review);
		btnModify = (Button) findViewById(R.id.btn_modify);
		btnSubmit = (Button) findViewById(R.id.btn_submit);

		showPlanLists(true);

		adapter = new PlanAdapter(getApplicationContext(), planLists);
		recordAdapter = new RecordAdapter(getApplicationContext(), consumeRecords);

		listViewPlan.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				if(indexAdapter == INDEX_RECORD){
					return;
				}
				indexAdapter = INDEX_RECORD;
				int month = planLists.get(position).getPlanMonth();
				
				currentRecords = null;
				currentRecords = new ArrayList<ConsumeRecord>();
				for (int i = 0; i < consumeRecords.size(); i++) {
					if(month == consumeRecords.get(i).getMonth()){
						currentRecords.add(consumeRecords.get(i));
					}
				}
				recordAdapter.setData(currentRecords);
				listViewPlan.setAdapter(recordAdapter);
				btnBack.setVisibility(View.VISIBLE);
			}
		});

		// 提交或是修改一个月计划
		btnSubmit.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				try {
					if (Integer.valueOf(editText_month.getText().toString()) < 1
							|| Integer.valueOf(editText_month.getText()
									.toString()) > 12) {
						Toast.makeText(getApplicationContext(), "输入的月份不正确！",
								Toast.LENGTH_SHORT).show();
					} else {
						int planMonth = Integer.valueOf(editText_month
								.getText().toString());
						int countOfSalary = Integer.valueOf(editText_salary
								.getText().toString());
						int countOfReward = Integer.valueOf(editText_reward
								.getText().toString());
						int countOfGain = Integer.valueOf(editText_gain
								.getText().toString());
						int countOfFood = Integer.valueOf(editText_food
								.getText().toString());
						int countOfClothes = Integer.valueOf(editText_clothes
								.getText().toString());
						int countOfLife = Integer.valueOf(editText_life
								.getText().toString());
						int countOfPlay = Integer.valueOf(editText_play
								.getText().toString());

						if (countOfSalary < 0 || countOfReward < 0
								|| countOfGain < 0 || countOfFood < 0
								|| countOfClothes < 0 || countOfLife < 0
								|| countOfPlay < 0) {
							Toast.makeText(getApplicationContext(), "金额不能为负数！",
									Toast.LENGTH_SHORT).show();
							return;
						}
						PlanUnit planUnit = new PlanUnit(planMonth,
								countOfSalary, countOfReward, countOfGain,
								countOfFood, countOfClothes, countOfLife,
								countOfPlay);
						boolean isExisted = false;
						for (int i = 0; i < planLists.size(); i++) {
							if (planLists.get(i).getPlanMonth() == planMonth) {
								isExisted = true;
								// 存在该月数据则修改
								planLists.get(i)
										.setCountOfSalary(countOfSalary);
								planLists.get(i)
										.setCountOfReward(countOfReward);
								planLists.get(i).setCountOfGain(countOfGain);
								planLists.get(i).setCountOfFood(countOfFood);
								planLists.get(i).setCountOfClothes(
										countOfClothes);
								planLists.get(i).setCountOfLife(countOfLife);
								planLists.get(i).setCountOfPlay(countOfPlay);
								Toast.makeText(getApplicationContext(),
										"修改" + planMonth + "月计划成功！",
										Toast.LENGTH_SHORT).show();
								break;
							}
						}
						if (!isExisted) {// 不存在该月数据则新增
							planLists.add(planUnit);
							Toast.makeText(getApplicationContext(),
									"新增" + planMonth + "月计划成功！",
									Toast.LENGTH_SHORT).show();

						}

					}
				} catch (NumberFormatException e) {
					// e.printStackTrace();
					Toast.makeText(getApplicationContext(),
							"无法修改，请检测输入的格式是否正确！", Toast.LENGTH_SHORT).show();

				}
			}
		});

		btnReview.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				showPlanLists(true);
				changeEditable(false);
			}
		});
		btnModify.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				showPlanLists(false);
				changeEditable(true);
			}
		});

		btnManage = (Button) findViewById(R.id.btn_manage);
		btnAdd = (Button) findViewById(R.id.btn_add);
		btnChart = (Button) findViewById(R.id.btn_chart);

		btnManage.setPressed(true);

		btnManage.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {

			}
		});
		btnAdd.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent1 = new Intent(getApplicationContext(),
						AddActivity.class);
				startActivity(intent1);
				finish();
			}
		});
		btnChart.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent2 = new SalesStackedBarChart()
						.execute(getApplicationContext());
				startActivity(intent2);
				// finish();
			}
		});

	}

	/**
	 * 设置是否可以编辑
	 * 
	 * @param editable
	 */
	private void changeEditable(boolean editable) {
		if (editable) {
			editText_salary.requestFocus();
		}
		editText_salary.setFocusableInTouchMode(editable);
		editText_salary.setFocusable(editable);

		editText_reward.setFocusableInTouchMode(editable);
		editText_reward.setFocusable(editable);

		editText_gain.setFocusableInTouchMode(editable);
		editText_gain.setFocusable(editable);

		editText_food.setFocusableInTouchMode(editable);
		editText_food.setFocusable(editable);

		editText_clothes.setFocusableInTouchMode(editable);
		editText_clothes.setFocusable(editable);

		editText_life.setFocusableInTouchMode(editable);
		editText_life.setFocusable(editable);

		editText_play.setFocusableInTouchMode(editable);
		editText_play.setFocusable(editable);

	}

	/**
	 * 是否要显示计划列表
	 * 
	 * @param showLists
	 */
	private void showPlanLists(boolean showLists) {
		if (showLists) {
			listViewPlan.setVisibility(View.VISIBLE);
			scrollViewPlan.setVisibility(View.GONE);

			if (adapter == null) {
				adapter = new PlanAdapter(getApplicationContext(), planLists);
			}
			listViewPlan.setAdapter(adapter);
			indexAdapter = INDEX_PLAN;

		} else {
			listViewPlan.setVisibility(View.GONE);
			scrollViewPlan.setVisibility(View.VISIBLE);
		}
		btnReview.setPressed(showLists);
		btnModify.setPressed(!showLists);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}
