package com.charge.work;

import java.util.ArrayList;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

/**
 * 
 * @author Carmack
 * 
 */
public class RecordAdapter extends BaseAdapter {
	private Context context;
	private LayoutInflater layoutInflater;
	private ArrayList<ConsumeRecord> list;

	public RecordAdapter(Context context, ArrayList<ConsumeRecord> list) {
		super();
		this.context = context;
		this.layoutInflater = LayoutInflater.from(this.context);
		this.list = list;
		Log.e("", list.size() + "!");
	}

	public int getCount() {
		return this.list != null ? this.list.size() : 0;
	}

	public Object getItem(int position) {
		return this.list != null ? this.list.get(position) : null;
	}

	public long getItemId(int position) {
		return position;
	}

	public View getView(int position, View convertView, ViewGroup parent) {
		ListItem listitem = null;
		if (position >= list.size())
			return null;
		final int pos = position;
		if (convertView == null) {
			listitem = new ListItem();
			convertView = layoutInflater.inflate(R.layout.consume_record, null);
			listitem.tv_Type = (TextView) convertView
					.findViewById(R.id.textView_type);
			listitem.tv_Item_Type = (TextView) convertView
					.findViewById(R.id.textView_item_type);
			listitem.tv_Money = (TextView) convertView
					.findViewById(R.id.textView_money);
			listitem.tv_Time = (TextView) convertView
					.findViewById(R.id.textView_time);

			convertView.setTag(listitem);
		} else {
			listitem = (ListItem) convertView.getTag();
		}

		// 设置数据
		if (list != null) {
			listitem.tv_Type
					.setText(list.get(position).getType() == ConsumeRecord.TYPE_INCOME ? "收入"
							: "支出");
			String item = " ";
			switch (list.get(position).getItemType()) {
			case ConsumeRecord.ITEM_TYPE_CLOTHES:
				item = "服装鞋帽";
				break;
			case ConsumeRecord.ITEM_TYPE_FOOD:
				item = "外出就餐";
				break;
			case ConsumeRecord.ITEM_TYPE_GAIN:
				item = "外快";
				break;
			case ConsumeRecord.ITEM_TYPE_LIFE:
				item = "日常开支";
				break;
			case ConsumeRecord.ITEM_TYPE_PLAY:
				item = "娱乐交际";
				break;
			case ConsumeRecord.ITEM_TYPE_REWARD:
				item = "奖金";
				break;
			case ConsumeRecord.ITEM_TYPE_SALARY:
				item = "工资";
				break;
			default:
				break;
			}
			listitem.tv_Item_Type.setText(item);
			listitem.tv_Money.setText("" + list.get(position).getMoney());
			listitem.tv_Time.setText("" + list.get(position).getTime());
		}
		return convertView;
	}

	/**
	 * 设置新数据并且更新UI
	 * 
	 * @param list
	 */
	public void setData(ArrayList<ConsumeRecord> data) {
		list = null;
		list = data;
		notifyDataSetChanged();
	}

	public void free() {
		list = null;
	}

	public class ListItem {
		public TextView tv_Type;
		public TextView tv_Item_Type;
		public TextView tv_Money;
		public TextView tv_Time;
	}

}